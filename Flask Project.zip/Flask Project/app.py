import re
from flask import Flask, request, render_template
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
import joblib
import nltk
nltk.download('stopwords')
from nltk.corpus import stopwords

# Initialize Flask app
app = Flask(__name__)

# Load your actual data
books_data = pd.read_csv('BOOKS_DATA_updated.csv')

# Filter only English books
books_data = books_data[books_data['Language'].str.lower() == 'english'].reset_index(drop=True)

# Load pre-trained models and vectorizer
vectorizer = joblib.load('tfidf_vectorizer.pkl')
nmf_model = joblib.load('nmf_model.pkl')
nmf_topics = joblib.load('nmf_topics.pkl')

# Preload stopwords set
stopwords_set = set(stopwords.words('english'))


# Custom list of words to ignore in search queries
common_words = {
    'top', 'books', 'about', 'suggest', 'suggestions', 'what', 'which', 'and', 'or', 
    'recommend', 'recommendations', 'good', 'find', 'search', 'best', 'my', 'your', 
    'me', 'you', 'for', 'of', 'in', 'to', 'some', 'any', 'on', 'show', 'give', 
    'list', 'with', 'please', 'I', 'i', 'want'
}

# Function to clean and preprocess the input query
def preprocess_query(query):
    # Remove any numbers
    query = re.sub(r'\d+', '', query)
    # Tokenize and remove stopwords and common irrelevant words
    query_tokens = re.findall(r'\w+', query.lower())
    filtered_query = [word for word in query_tokens if word not in stopwords_set and word not in common_words]
    return " ".join(filtered_query)

# Function to find books by input sentence
def find_books_by_sentence(sentence, top_n=10):
    try:
        # Preprocess the input sentence
        processed_sentence = preprocess_query(sentence)
        
        # Transform the cleaned sentence
        sentence_vector = vectorizer.transform([processed_sentence])
        sentence_topic_distribution = nmf_model.transform(sentence_vector)
        similarities = cosine_similarity(sentence_topic_distribution, nmf_topics).flatten()
        
        books_data['Similarity'] = similarities
        books_data_sorted = books_data.sort_values(by='Similarity', ascending=False).reset_index(drop=True)
        
        return books_data_sorted[['Title', 'Author', 'Year']].head(top_n)
    except Exception as e:
        print(f"Error finding books: {e}")
        return pd.DataFrame(columns=['Title', 'Author', 'Year'])

# Route to render the home page
@app.route('/')
def index():
    return render_template('index.html')

# Route to handle recommendations
@app.route('/recommend', methods=['POST'])
def recommend_books():
    try:
        sentence = request.form['query']
        top_n = extract_top_n_from_sentence(sentence)
        recommendations = find_books_by_sentence(sentence, top_n)
        
        # Convert the recommendations DataFrame to a list of dictionaries
        results = recommendations.to_dict('records')
        if not results:
            results = [{'Title': 'No results found', 'Author': '', 'Year': ''}]
        
        return render_template('results.html', results=results, top_n=top_n)
    except Exception as e:
        print(f"Error in recommendation: {e}")
        return render_template('results.html', results=[{'Title': 'Error', 'Author': str(e), 'Year': ''}], top_n=0)

# Function to extract the number of recommendations from the input sentence (if specified)
def extract_top_n_from_sentence(sentence):
    match = re.search(r'(\d+)', sentence.lower())
    if match:
        return int(match.group(1))
    else:
        return 10  # Default to top 10 recommendations if no number is specified

# Run the Flask app
if __name__ == '__main__':
    app.run(debug=True)
